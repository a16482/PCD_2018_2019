import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;


public class SlotMachine {

	static final int N_SLOTS = 3;
	private JFrame frame;
	private JLabel[] imageLabels = new JLabel[N_SLOTS];
	private Wheel[] wheels = new Wheel[N_SLOTS];
//	private ImageIcon[] images = new ImageIcon[3];
	private JButton start;
	private JButton stop;
	private boolean started = false;
	
	public SlotMachine() {
	
			frame = new JFrame();
			frame.setLayout(new BorderLayout());
			JPanel imagePanel = new JPanel();
			for (int i = 0; i != N_SLOTS; ++i) {
				imageLabels[i] = new JLabel();
				imageLabels[i].setPreferredSize(new Dimension(60, 60));
				imagePanel.add(imageLabels[i]);
				ImageIcon a = new ImageIcon("im1.jpg");
				imageLabels[i].setIcon(a);
				//imageLabels[i].setText("BUMMER");
			}
			frame.add(imagePanel, BorderLayout.CENTER);
			JPanel buttonPanel = new JPanel();
			start = new JButton("Start");
			start.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					if (started)
						return;
					for (int i = 0; i != N_SLOTS; i++){
						wheels[i] = new Wheel(imageLabels[i]); 
						wheels[i].start();
					}
					started = true;
				}
			});
			buttonPanel.add(start);
			stop = new JButton("Stop");
			stop.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					if (!started)
						return;
					for (int i = 0; i != N_SLOTS; i++){
						wheels[i].interrupt();
					}
					for (int i = 0; i != N_SLOTS; i++){
						try {
							wheels[i].join();
						} catch (InterruptedException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}
					started = false;
				}
			});
			buttonPanel.add(stop);
			frame.add(buttonPanel, BorderLayout.SOUTH);
			frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			frame.pack();
	}
	
	
	public static void main(String[] args) {
		SlotMachine m = new SlotMachine();
		m.on();
	}

	private void on() {
		frame.setVisible(true);
	}

}
