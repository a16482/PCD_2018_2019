import java.util.Random;

import javax.swing.ImageIcon;
import javax.swing.JLabel;

public class Wheel extends Thread {

	private static final int MAX_SLEEP = 10;
	private JLabel label;

	public Wheel(JLabel label) {
		this.label = label;
	}

	public void run() {
		Random r = new Random();
		int n = 0;
		try {
			while (!interrupted()) {
				sleep(r.nextInt(MAX_SLEEP));
				n = r.nextInt(3	) + 1;
				label.setIcon(new ImageIcon("im" + n + ".jpg"));
			}
		} catch (InterruptedException e) {
			
		}
	}
}
