package ex3;

import java.awt.Container;
import java.awt.GridLayout;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

/*
 * Desenvolva uma aplica??o que permita converter imagens a cores em imagens a preto e branco. 
 * A aplica??o deve usar 10 processos ligeiros para converter os v?rios pixels da imagem.
 *  Deve implementar uma classe Pixel que cont?m a informa??o da posi??o do pixel e do valor 
 *  de RGB. Deve igualmente implementar uma classe Imagem com os seguintes m?todos:
 */

public class ConverteImagens {

	private static final int N_THREADS = 10;
	private static final String FILENAME = "timor1.jpg";

	private JFrame window;
	private Imagem imagem;
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {

		try {
			new ConverteImagens().executa();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	public ConverteImagens() throws IOException {
		window = new JFrame();
		Container c = window.getContentPane();
		c.setLayout(new GridLayout(1, 2));
		this.imagem = null;
		JLabel b2 = new JLabel();
		imagem = new Imagem(FILENAME,b2);
		JLabel b1 = new JLabel();
		window.getContentPane().add(b1);
		b1.setIcon(new ImageIcon(ImageIO.read(new File("timor1.jpg"))));
//		b1.setIcon(new ImageIcon(imagem.getImage()));
		b2.setIcon(new ImageIcon(imagem.getBWImage()));
		window.getContentPane().add(b2);
		window.pack();
		window.setVisible(true);
	}

	private void executa() {
		
		try {
			
			Conversor[] conversores = new Conversor[N_THREADS];
			for (int i = 0; i != N_THREADS; i++) {
				conversores[i] = new Conversor(imagem);
			}
			for (int i = 0; i != N_THREADS; i++) {
				conversores[i].start();
			}

			for (int i = 0; i != N_THREADS; i++) {
				conversores[i].join();
			}
			System.out.println("Terminado");
			
		} catch (InterruptedException e) {
			System.out.println("Interrupted?");
		}
		
		
	}

}
