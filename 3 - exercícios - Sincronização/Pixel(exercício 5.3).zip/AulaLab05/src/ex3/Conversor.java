package ex3;

public class Conversor extends Thread {

	private Imagem imagem;

	public Conversor(Imagem imagem) {
		this.imagem = imagem;
	}

	public void run() {
		Pixel nextPixel = imagem.nextPixel();
		while (nextPixel != null) {
			imagem.updatePixel(converte(nextPixel));
			nextPixel = imagem.nextPixel();
		}
	}

	private Pixel converte(Pixel p) {
		int a = (int) (0.2126 * p.getR() + 0.7152 * p.getG() + 0.0722 * p.getB());
		return new Pixel(p.getX(), p.getY(),  a, a, a, a );
	}

}
