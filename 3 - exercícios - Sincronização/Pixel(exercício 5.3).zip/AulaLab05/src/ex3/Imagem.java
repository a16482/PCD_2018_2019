package ex3;

import java.awt.Color;
import java.awt.Component;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JLabel;

public class Imagem {

	private int nextPixelIndex;
	private Pixel[] pixels;
	private BufferedImage image;
	private BufferedImage bwimage;
	private JLabel label;

	// private int nRows;
	// private int nCols;

	public Imagem(String ficheiro, JLabel label) throws IOException {
		image = ImageIO.read(new File(ficheiro));
		bwimage = ImageIO.read(new File(ficheiro));
		pixels = new Pixel[image.getHeight() * image.getWidth()];
		this.label = label;
		for (int i = 0; i != image.getWidth(); i++)
			for (int j = 0; j != image.getHeight(); j++) {
				Color color = new Color(image.getRGB(i, j));
				int alpha = color.getAlpha();
				int red = color.getRed();
				int green = color.getGreen();
				int blue = color.getBlue();
				pixels[i * image.getHeight() + j] = new Pixel(i, j, alpha, red,
						green, blue);
			}
	}

	// -> m?todo que devolve o pr?ximo pixel a ser convertido.
	public synchronized Pixel nextPixel() {
		if (nextPixelIndex < pixels.length)
			return pixels[nextPixelIndex++];
		return null;
	}

	// -> m?todo que recebe um pixel com um novo valor de RGB e o actualiza na
	// imagem.

	public synchronized void updatePixel(Pixel p) {
		pixels[p.getX() * image.getHeight() + p.getY()] = p;
		Color newColor = new Color(p.getR(), p.getG(), p.getB(), p.getA());
		bwimage.setRGB(p.getX(), p.getY(), newColor.getRGB());
		System.out.println(p.getX() + "," + p.getY() + " - "
				+ newColor.toString());
		
		label.setIcon(new ImageIcon(bwimage));
	}

	public BufferedImage getImage() {
		return image;
	}

	public BufferedImage getBWImage() {
		return bwimage;
	}

}
