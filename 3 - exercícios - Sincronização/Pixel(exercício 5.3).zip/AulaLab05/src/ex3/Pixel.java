
package ex3;

public class Pixel {

	private int x;
	private int y;
	private int A;
	private int R;
	private int G;
	private int B;
	

	public Pixel(int x, int y, int a, int r, int g, int b) {
		super();
		this.x = x;
		this.y = y;
		A = a;
		R = r;
		G = g;
		B = b;
	}
	public int getX() {
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}
	public int getA() {
		return A;
	}
	public void setA(int a) {
		A = a;
	}
	public int getR() {
		return R;
	}
	public void setR(int r) {
		R = r;
	}
	public int getG() {
		return G;
	}
	public void setG(int g) {
		G = g;
	}
	public int getB() {
		return B;
	}
	public void setB(int b) {
		B = b;
	}
	
}
