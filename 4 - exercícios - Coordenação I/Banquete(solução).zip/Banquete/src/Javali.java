public class Javali {
	private int id;
	private int cozinheiro;

	public Javali(int id, int cozinheiro) {
		super();
		this.id = id;
		this.cozinheiro = cozinheiro;
	}

	@Override
	public String toString() {
		return "Javali [id=" + id + ", cozinheiro=" + cozinheiro + "]";
	}
}
