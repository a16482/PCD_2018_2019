import java.util.LinkedList;

public class Mesa {

	private int capacidade;
	private LinkedList<Javali> mesa = new LinkedList<Javali>();
	
	public Mesa(int capacidade) {
		super();
		this.capacidade = capacidade;
	}

	public synchronized void poe(Javali javali) throws InterruptedException {
		while(estaCheia()){
			wait();
		}
		mesa.addLast(javali);
		notifyAll();
	}

	private boolean estaCheia() {
		return mesa.size() == capacidade;
	}

	public synchronized Javali retira() throws InterruptedException {
		while(estaVazia()){
			wait();
		}
		notifyAll();
		return mesa.pollFirst();
	}

	private boolean estaVazia() {
		return mesa.isEmpty();
	}

}
