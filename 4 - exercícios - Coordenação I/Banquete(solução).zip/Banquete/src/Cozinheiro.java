public class Cozinheiro extends Thread {
	private int id;
	private Mesa mesa;

	public Cozinheiro(int id, Mesa mesa) {
		super();
		this.id = id;
		this.mesa = mesa;
	}

	@Override
	public void run() {
		int numJavali = 0;
		try {
			while (!interrupted()) {
				Javali javali = new Javali(numJavali, id);
				numJavali++;
				mesa.poe(javali);
				System.out.println("C" + id + " -> " + javali);
				sleep((int) (Math.random() * 1000));
			}
		} catch (InterruptedException e) {
			System.out.println("C" + id + " acabou!");
		}
	}
}
