
public class Glutao extends Thread {
	private int id;
	private Mesa mesa;

	public Glutao(int id, Mesa mesa) {
		super();
		this.id = id;
		this.mesa = mesa;
	}

	@Override
	public void run() {
		try {
			while (!interrupted()) {
				Javali javali = mesa.retira();
				System.out.println("G" + id + " <- " + javali);
				sleep((int) (Math.random() * 1000));
			}
		} catch (InterruptedException e) {
			System.out.println("G" + id + " acabou!");
		}
	}
}
