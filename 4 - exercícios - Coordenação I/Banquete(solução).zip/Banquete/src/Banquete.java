import java.util.ArrayList;

public class Banquete {
	private static final int CAPACIDADE = 10;
	private static final int NUM_GLUTOES = 15;
	private static final int NUM_COZ = 20;
	private Mesa mesa;
	private ArrayList<Cozinheiro> cozinheiros = new ArrayList<Cozinheiro>();
	private ArrayList<Glutao> glutoes = new ArrayList<Glutao>();

	private void init() {
		mesa = new Mesa(CAPACIDADE);
		for (int i = 0; i < NUM_COZ; i++) {
			cozinheiros.add(new Cozinheiro(i, mesa));
			cozinheiros.get(i).start();
		}
		for (int i = 0; i < NUM_GLUTOES; i++) {
			glutoes.add(new Glutao(i, mesa));
			glutoes.get(i).start();
		}
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		for (int i = 0; i < NUM_COZ; i++) {
			cozinheiros.get(i).interrupt();
			try {
				cozinheiros.get(i).join();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		for (int i = 0; i < NUM_GLUTOES; i++) {
			glutoes.get(i).interrupt();
			try {
				glutoes.get(i).join();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		System.out.println("FIM da festa!");
	}

	public static void main(String[] args) {
		new Banquete().init();
	}
}
