package pt.iul.dcti.pcd.race;

import java.util.Observable;

public class Car extends Observable {
	private int id;
	private int limite;
	private int posicao=0;
	
	public int getId() {
		return id;
	}

	public int getPosicao() {
		return posicao;
	}

	public Car(int id, int limite) {
		super();
		this.id = id;
		this.limite = limite;
	}
	
	
}
