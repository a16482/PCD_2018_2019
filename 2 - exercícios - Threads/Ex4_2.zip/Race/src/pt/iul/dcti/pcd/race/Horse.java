package pt.iul.dcti.pcd.race;

import java.awt.Color;

import javax.swing.JTextField;

public class Horse extends Thread {
	private JTextField track;
	private Race race;

	public Horse(JTextField track, Race race) {
		super();
		this.track = track;
		this.race = race;
	}

	@Override
	public void run() {
		try {
			for (int i = 30; i >= 0; i--) {
				sleep((int) (Math.random() * 1000));
				track.setText(Integer.toString(i));
			}
			race.end();
			track.setBackground(Color.GREEN);
		} catch (InterruptedException e) {
			track.setBackground(Color.LIGHT_GRAY);
		}

	}
}
