package pt.iul.dcti.pcd.race;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Race {
	private static final int NUM_HORSES = 2000;
	private JFrame frame = new JFrame("Race");
	private JTextField[] tracks = new JTextField[NUM_HORSES];
	private Horse horses[] = new Horse[NUM_HORSES];
	private JButton start;

	public Race() {
		buildGUI();
		createHorses();
		// TODO Auto-generated constructor stub
	}

	private void createHorses() {
		for(int i =0; i < NUM_HORSES;i++){
			horses[i] = new Horse(tracks[i], this);
		}	
	}

	private void buildGUI() {
		Container c = frame.getContentPane();
		JPanel panel = new JPanel();
		for (int i = 0; i < NUM_HORSES; i++) {
			tracks[i] = new JTextField("30");
			panel.add(tracks[i]);
		}
		c.add(panel);
			
		start = new JButton("Start");	
		c.add(start, BorderLayout.SOUTH);
		start.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				for(Horse horse: horses){
					horse.start();
				}
				start.setEnabled(false);
			}
		});
		
		frame.setSize(1000, 1000);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
	}

	public void end(){
		for(Horse horse: horses){
			horse.interrupt();
		}
	}
	
	private void init() {
		frame.setVisible(true);
	}

	public static void main(String[] args) {
		new Race().init();
	}

}
