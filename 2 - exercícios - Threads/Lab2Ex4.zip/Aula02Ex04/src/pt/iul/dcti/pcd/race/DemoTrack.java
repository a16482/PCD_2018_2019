package pt.iul.dcti.pcd.race;

import javax.swing.JFrame;

public class DemoTrack {

	public static void main(String[] args) {
		JFrame frame = new JFrame("Demo Track");
		Track track = new Track(3, 10);
		track.moveCar(1, 3);
		track.moveCar(2, 6);
		frame.add(track);
		frame.setSize(500, 300);
		frame.setVisible(true);
	}

}
